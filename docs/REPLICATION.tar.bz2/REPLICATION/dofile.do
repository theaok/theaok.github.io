*NOTE: use google if you do not know what something mean, e.g. google "stata, capture" or  "stata, mkdir"
/* if google doesn't work, use elearning to post questions */

/* note how many comments i use -- use even more comments than me */
  
/*********************************/
/* Working Hours in Europe vs US */
/*********************************/

*TO DO:
*many additional vars commented out that can be used in the future  

/* you need to adjust path here to your folder */
cd "~/desk/papers/old/2009/ditella/REPLICATION/"        

/* these will genereate folders */
capture mkdir "`d'tex"                 
capture mkdir "`d'out"                 
capture mkdir "`d'res"             
capture mkdir "`d'lit"                 
capture mkdir "`d'dat"                
capture mkdir "`d'scr"

clear                                  
set mem 500m                           
capture set maxvar 10000
version 10                             
set more off                           


/*******/
/* wvs */
/*******/
*data comes from www.worldvaluessurvey.org/ 
use dat/base/wvs/wvs.dta  , clear
ren a003 leisure
ren c008 work_leisure
ren a170 lifests
decode s003, gen(ctry)
gen europe=.
replace europe =1 if ctry=="belgium"|  ctry=="czech republic"|  ctry=="denmark"|  ctry=="estonia"|  ctry=="finland"|  ctry=="france"|  ctry=="great britain"|  ctry=="hungary"|  ctry=="italy"|  ctry=="latvia"|  ctry=="lithuania"
replace europe=0 if ctry=="united states"
drop if europe==.
la def e_lbl 0 "America" 1"Europe"
la val europe e_lbl
des a005 c030 c031 c038 c040 c041 c042 c063 e040 c027
sum a005 c030 c031 c038 c040 c041 c042 c063 e040 c027

tab work_leisure
tab work_leisure, nola mi

tab a005
tab a005, nola mi
replace a005=5-a005

tab e040
tab e040 , nola mi
replace e040=11-e040

egen lei=std(leisure)
egen w_l=std(work_leisure)
egen w_i =std(a005)
egen w_s=std(e040)


graph hbar  (mean) w_l (mean) w_i (mean) w_s, over(europe) bargap(-50)
graph hbar  (mean) w_l (mean) w_i (mean) w_s, over(europe) bar(1, fcolor(gs15) lcolor(black) lwidth(medthin) lpattern(solid)) bar(2, fcolor(gs8) lcolor(black) lwidth(medthin) lpattern(solid)) bar(3, fcolor(gs0) lcolor(black) lwidth(medthin) lpattern(solid)) bar(4, fcolor(white) lcolor(black) lwidth(medthin) lpattern(solid)) scheme(s2mono) legend( lab(1 "leisure-work") lab(2 "work important") lab(3 "success"))
graph export out/g2.eps, as(eps)  replace
 
/* I am converting eps to pdf, this is how you do it on linux -- if you are on windows you can use */
/* adobe professional to convert eps to pdf and to crop it(if needed). of course if you are on windows, */
/* comment out these lines throught the do-file  */
sh(epstopdf out/g2.eps)                        
sh(xpdf out/g2.pdf)                        


/*******/
/* gss */
/*******/
*data come from www.norc.org/GSS+Website/  
*//____________________________________________________________________________________________________________
*// additional vars fr the future

/* replace wktopsat=5-wktopsat */
/* replace satjob=5-satjob */
/* des satfin  satjob1 satjob7 satfam7 hrs2 hrs1 workhr hrsmoney hrsrelax  */
/* sum satfin  satjob1 satjob7 satfam7 hrs2 hrs1 workhr hrsmoney hrsrelax */

*//____________________________________________________________________________________________________________

use dat/base/gss/remp7206iap.dta, clear
*//----------------------------------------------------------------------------------------

keep if year ==2000|year==2002|year==1996|year==1998

codebook happy
recode happy (1=3 "3(very happy)") (2=2 "2(pretty happy)") (3=1 "1(not too happy)"), gen(hhh)
drop  happy
ren hhh happy

codebook marital
recode marital (1=1 "1(married)") (nonm=0 "0(widowed, divorced, separated, never married)"), gen(mar)
la var mar "married"

*//it is age of res2
drop age2
gen age2=age^2
la var age2 "age  squared"

codebook wrkstat, tab(100)
recode  wrkstat (3 4=1 "1(temp not working unempl, laid off)") (nonm=0 "0(retired; school; keeping house; other;orking fulltime, working parttime)"),gen(un)
la var un "unemployed"

*//use these for 96
replace income91=. if income91==22
xtile inc91=income91, nq(4)

*//use these for 98, 00, 02
replace income98=. if income98==24
xtile inc98=income98 if year==1998, nq(4)
xtile inc00=income98 if year==2000, nq(4)
xtile inc02=income98 if year==2002, nq(4)

gen inc =.
replace inc=inc91 if year==1996
replace inc=inc98 if year==1998
replace inc=inc00 if year==2000
replace inc=inc02 if year==2002
recode inc (1=1 "1(1st quartile)") (4=4 "4(4th quartile)"),gen(aok1)
drop inc
ren aok1 inc
la var inc "hh income"

gen ds_id ="gss"

tab region , gen(gss_reg_d)
ren region gss_region

codebook famwkoff, tab(100)
la def hard_lbl 1"1(not at all hard)" 2"2(not too hard)" 3"3(somewhat hard)"  4"4(very hard)"
la val famwkoff hard_lbl
ren famwkoff gss_fam_tim 
la var gss_fam_tim "family time"

recode sex (1=1 "male") (2=0 "female"), gen(male)

codebook mustwork
recode mustwork (1=1 "1(yes)") (2=0 "0(no)"), gen(gss_ext_hrs) 
la var gss_ext_hrs "extra hours"

codebook socfrend
recode socfrend (1=7 "7(almost daily)") (2=6 "6(sev times a week)") (3=5 "5(sev times a mnth)") (4=4 "4(once a month)") (5=3 "3(sev times a year)") (6=2 "2(once a year)") (7=1 "1(never)"), gen(gss_fnd)
la var gss_fnd "friends"

codebook health 
recode   health  (1=4 "4(excellent)") (2=3 "3(good)") (3=2 "2(fair)") (4=1 "1(poor)"), gen(gss_health)

tostring(isco88),gen(isco2)             
replace isco2=substr(isco2,1,2)
la var isco2 "2 digit occupation"
gen isco1=substr(isco2,1,1)
tab isco1
la var isco1 "occupation"

la def isco1_lbl 1 "professional" 2 "administrative" 3"clerical" 4"sales" 5"service" 6"agriculure" 7"production,transport" 8"craft, technical" 9"craft, technical2"
destring isco1, replace
la val isco1 isco1_lbl
replace isco1=8 if isco1==9

keep year happy mar age2 age un inc gss_region ds_id gss_reg_d* gss_fam_tim male gss_ext_hrs gss_fnd gss_health hrs1 isco1

 
save dat/ditella1.dta, replace

*NOTE EB datasets come from ICPSR

/* i commented out the whole block of text below-- there are variable names that i may want to use in */
/* the future */

/***********************/
/* eb_social_exclusion01 */
/***********************/
/* V216            int    %33.0g      V216       Q34 JOB SIT COMPARED: */
/*                                                 SATISFACTION */
/* V218            int    %33.0g      V218       Q36 WORKPLACE CHANGES - */
/*                                                 DECISION SATISF */
/* V223            int    %33.0g      V223       Q40 JOB SATISFAC: PAY */
/* V224            int    %33.0g      V224       Q40 JOB SATISFAC: USE ABILITIES */
/* V225            int    %33.0g      V225       Q40 JOB SATISFAC: OWN INITIATIVE */
/* V226            int    %33.0g      V226       Q40 JOB SATISFAC: OWN */
/*                                                 DEVELOPMENT */
/* V227            int    %33.0g      V227       Q40 JOB SATISFAC: CREATIVITY */
/*                                                 SCOPE */
/* V228            int    %33.0g      V228       Q40 JOB SATISFAC: WORKING HOURS */
/* V229            int    %33.0g      V229       Q40 JOB SATISFAC: WORK AMOUNT */
/* V230            int    %33.0g      V230       Q40 JOB SATISFAC: WORK VARIETY */
/* V231            int    %33.0g      V231       Q40 JOB SATISFAC: WORK TARGETS */
/* V232            int    %33.0g      V232       Q40 JOB SATISFAC: SECURITY */
/* V233            int    %33.0g      V233       Q40 JOB SATISFAC: RELATIONS W */
/*                                                 MANAGER */
/* V234            int    %33.0g      V234       Q40 JOB SATISFAC: PROMOTION */
/*                                                 PROSPECTS */
/* V235            int    %33.0g      V235       Q40 JOB SATISFAC: TRAINING */
/* V236            int    %33.0g      V236       Q40 JOB SATISFAC: USEFUL PART I */
/*                                                 SOCIETY */
/* V237            int    %33.0g      V237       Q40 JOB SATISFACTION */
/* V285            int    %20.0g      V285       Q46 LIFE SATISFACTION */
/* V286            int    %20.0g      V286       Q46 LIFE SATISFACTION - LEISURE */
/*                                                 AT HOME */
/* V287            int    %20.0g      V287       Q46 LIFE SATISFACTION - SOCIAL */
/*                                                 LIFE */
/* V288            int    %20.0g      V288       Q46 LIFE SATISFACTION - FAMILY */
/*                                                 LIFE */
/* V289            int    %20.0g      V289       Q46 DEMOCRACY SATISFACTION */
/* V290            int    %20.0g      V290       Q46 SATISFACTION WITH KIND OF */
/*                                                 SOCIETY */
/* V155            int    %33.0g      V155       Q23 JOB CONDITIONS: FLEX */
/*                                                 WORKING HOURS */
/* V157            int    %33.0g      V157       Q23 JOB CONDITIONS: CONV HOURS */
/*                                                 OF WORK */
/* V167            int    %33.0g      V167       Q29 OCCUPATION - WORKING HOURS */
/*                                                 A WEEK */
/* V168            int    %33.0g      V168       Q29R OCCUPATION - WORKING HOURS */
/*                                                 A WEEK R */
/* V170            int    %33.0g      V170       Q30B WORKING HOURS - FREE */
/*                                                 PREFERENCE */
/* V171            int    %33.0g      V171       Q30B WORKING HOURS - FREE */
/*                                                 PREFERENCE R */
/* V176            int    %33.0g      V176       Q31 JOB SITUATION: WORKING */
/*                                                 HOURS VARY */
/* V228            int    %33.0g      V228       Q40 JOB SATISFAC: WORKING HOURS */

*//--------------------------------------------------------

/* ren V237 job_sts */
/* codebook job_sts */
  
/* ren V287 soc_sts */
/* codebook soc_sts */
/* replace soc_sts=5-soc_sts */

/* ren V288 fam_sts */
/* codebook fam_sts */
/* replace fam_sts=5-fam_sts */
/* ren V228 sts_hrs */
/* codebook sts_hrs */
/* codebook V286 */
/* ren V286 lei_hme_sts */



*//interesting preferences for working hours

/* ren V170 hrs_pre */
/* codebook hrs_pre */
/* ren V171 hrs_pre_r */
/* codebook hrs_pre_r */

  
*//--------------------------------------------------------

*//this can be another paper including variables below along with other for social capital
/* des V104 */
/* bys happy:sum V104  */
/* bys happy:sum V105 */
/* bys happy:sum V109 */



*//political affiliation

/* des V425-V427 */


/*V145 has detailed types of occ : may use this */

*//lots of good variables for income !!! eg in relation to others--another paper?
  
*//lots of good variables for social capital, social exclusion--may use it for cities lol


*//____________________________________________________________________________________________________________
use "dat/base/eu_01social_exclusion/03475-0001-Data.dta", clear
do "dat/base/eu_01social_exclusion/03475-0001-Supplemental_syntax.do"
*//____________________________________________________________________________________________________________


codebook V285
recode V285 (1=3 "3(very satisfied)") (2=2 "2(fairly satisfied)") (3 4=1 "1(not very satisfied; not at all satisfied )"), gen(happy)
la var happy "happy"

codebook V167 
ren V167 hrs1

ren V432 age 
gen age2 =age^2

codebook V145, tab(100)
recode V145 (3=1 "1(unemployed or temporarily not working)") (nonm=0 "0(otherwise)"), gen(un)

codebook V428
recode V428 (1 2 =1  "1(married; remarried)") (nonm=0 "0(otherwise)"), gen(mar)

codebook V458
ren V458 inc 
recode inc (1=1 "1(1st quartile)") (4=4 "4(4th quartile)"),gen(aok1)
drop inc
ren aok1 inc
la var inc "income"

codebook V107
recode V107   (1=1 "1(yes)") (2=0 "0(no)") (4=.)    ,gen(eb01_fnd)

gen ds_id ="eb01"

codebook V6, tab(100)
recode V6 (15=14 "finland") (16=15 "sweden") (17=16 "austria"), gen(ctry)

codebook V123
recode V123 (1=4 "4(very good)") (2=3 "3(fairly good)")  (3=2 "2(fairly bad)") (4=1 "1(very bad)")       ,gen(eb01_health) 


ren V513 eb01_occ 
ren V162 eb01_occ2 
ren V163 eb01_occ3 
ren V196 eb01_ext_hrs  

codebook V246
recode V246  (7=.) (1=5 "5(always)")  (2=4 "4(often)")   (3=3 "3(sometimes)")  (4=2 "2(hardly ever)") (5=1 "1(never)")   , gen(eb01_fam_tim) 

recode V431 (1=1 "1(male)") (2=0 "0(female)"), gen(male)

keep happy ctry hrs1 age2 age un mar inc eb01_fnd ds_id eb01_health eb01_occ eb01_occ2 eb01_occ3 eb01_ext_hrs eb01_fam_tim male 
save dat/soc_exc2.dta, replace

/***********************/
/* eb_emp_gender  96*/
/***********************/
/* v111            byte   %8.0g       V111FT     q19_6 work: hours vary */
/* v134            int    %8.0g       V134FT     q23a work hours per week */
/* v135            byte   %8.0g       V135FT     q23a work hours per week */
/*                                                 (recoded) */
/* v136            byte   %8.0g       V136FT     q23b work hours per week other */
/*                                                 jobs */
/* v178            byte   %8.0g       V178FT     q36a_4 job satisfaction: work */
/*                                                 hours */
/* v203            byte   %8.0g       V203FT     q40b ideal number of work hours */
/* v204            byte   %8.0g       V204FT     q40b ideal number of work hours */
/*                                                 (rec) */
/* v234            byte   %8.0g       V234FT     q53b ideal number of work hours */
/* v235            byte   %8.0g       V235FT     q53b ideal number of work hours */
/*                                                 (rec) */
/* v268            byte   %8.0g       V268FT     q61 look for job: hours spent */
/* v341            byte   %8.0g       V341FT     q77_8 choose job: flexible */
/*                                                 working hours */
/* v343            byte   %8.0g       V343FT     q77_10 choose job: convenient */
/*                                                 work hours */
/* v399            byte   %8.0g       V399FT     q92_7 part-/full-timers: family */
/*                                                 life */
/* v475            byte   %8.0g       V475FT     q104_1 satisfaction: life */
/* v476            byte   %8.0g       V476FT     q104_2 satisfaction: leisure */
/*                                                 life */
/* v477            byte   %8.0g       V477FT     q104_3 satisfaction: social life */
/* v478            byte   %8.0g       V478FT     q104_4 satisfaction: family life */
/* v53             byte   %8.0g       V53FT      q3 polit discussion - convince */
/*                                                 friends */
/* v243            byte   %8.0g       V243FT     q54_8 no job - friends look */
/*                                                 down at you */
/* v256            byte   %8.0g       V256FT     q60a_2 look for job: asked */
/*                                                 friends */
/* v373            byte   %8.0g       V373FT     q87a friends: unemployed */
/* v374            byte   %8.0g       V374FT     q87b friends: have paid job */
*//v373            byte   %8.0g       V373FT     q87a friends: unemployed

/* v203            byte   %8.0g       V203FT     q40b ideal number of work hours */
/* v204            byte   %8.0g       V204FT     q40b ideal number of work hours */
/*                                                 (rec) */
/* v234            byte   %8.0g       V234FT     q53b ideal number of work hours */
/* v235            byte   %8.0g       V235FT     q53b ideal number of work hours */

  *//lookfor work gives lots of work stuff:a paper working environment->life satisfaction
/* V373 Q87A FRIENDS: UNEMPLOYED .................... 310 */
/* V374 Q87B FRIENDS: HAVE PAID JOB ................. 311 */
/* V375 Q88_1 FAMILY UNEMPLMNT: NO ONE .............. 312 */
/* V376 Q88_2 FAMILY UNEMPLMNT: PARTNER ............. 313 */
/* V377 Q88_3 FAMILY UNEMPLMNT: CHILD AT HOME ....... 314 */
/* V378 Q88_4 FAMILY UNEMPLMNT: CHILD ELSEWHERE ..... 314 */
/* V379 Q88_5 FAMILY UNEMPLMNT: MOTHER/FATHER ....... 315 */
/* V380 Q88_6 FAMILY UNEMPLMNT: ANOTHER RELATIVE .... 316 */


*//good stuff here like job status, socio prof status
/* tab v56, nola mi */

*//if spouse unmenployd less satisfied --interesting
/* tab v56 */
/* bys v56:sum happy */

*//detailed isco
/* des v80 */

/* ren v203 ideal_hrs */
  
use "dat/base/eu243_emp_gender/eu2443.dta", clear
codebook v134, tab(100)
ren v134 hrs1 
codebook v136, tab(100)
ren v136 eb96_hrs_other_jobs 

codebook v475, tab(100)
recode v475 (1=3 "3(very satisfied)") (2=2 "2(fairly satisfied)") (3 4=1 "1(not very satisfied; not at all satisfied )"), gen(happy)
la var happy "happy"

*//this is alternative one to double check things revise and resubmit duh
codebook v362, tab(100)
recode v362 (1=3 "3(very satisfied)") (2=2 "2(fairly satisfied)") (3 4=1 "1(not very satisfied; not at all satisfied )"), gen(happy_alt)
la var happy "happy"


ren v513 age 
gen age2 =age^2

tab v529, nola
xtile inc =v529, nq(4)
recode inc (1=1 "1(1st quartile)") (4=4 "4(4th quartile)"),gen(aok1)
drop inc
ren aok1 inc
la var inc "income"

codebook v369
recode v369  (1=8 "8(several times a week)") (2=7 "7(about weekly)") (3=6 "6(about fortnightly)") (4=5 "5(about monthly)")  (5=4 "4(a few times a year)") (6=3 "3(once a year)") (7=2 "2(less often than once a year)") (8=1 "1(never)")  , gen(eb96_fnd) 


codebook v57
recode v57 (1 2 3=1  "1(married; remarried; umarried, living with partner)") (nonm=0 "0(otherwise)"), gen(mar)

lookfor occupation
ren v520 eb96_occ1 
ren v553 eb96_occ2 

codebook v67, tab(100)
recode v67 (8 10 =1 "1(unemployed; permanantly unable to work, sick/disabled") (nonm=0 "0(otherwise)"), gen(un)

ren v6 ctry 
gen ds_id="eb96"

codebook v74  
recode v74 (0=0 "0(not  mentioned)") (1=1 "1(mentioned)") ,gen(eb96_fam_tim)
la var eb96_fam_tim "family time"

codebook v125
recode v125  (1=5 "5(strongly agree)")  (2=4 "4(agree)") (3=3 "3(neither agree / nor disagree)") (4=2 "2(disagree)") (5=1 "1(strongly disagree)")  ,gen(eb96_ext_hrs) 
la var eb96_ext_hrs "extra hours"

recode v512 (1=1 "1(male)") (2=0 "0(female)"), gen(male)

keep hrs1 eb96_hrs_other_jobs happy age age2 inc eb96_fnd mar eb96_occ1 eb96_occ2 un ctry eb96_fam_tim eb96_ext_hrs male ds_id happy_alt
save dat/emp_gender2.dta, replace


/**********/
/* append */
/**********/
use  dat/ditella1.dta, clear
append using  dat/emp_gender2.dta
append using  dat/soc_exc2.dta

*//---

gen eb=(ds_id=="eb96"|ds_id=="eb01")
  
*//work hours categories
codebook hrs1, tab(190)
gen hrs_c=.
replace hrs_c =1 if hrs1<17& hrs1>0
replace hrs_c =2 if hrs1<35& hrs1>16
replace hrs_c =3 if hrs1<40& hrs1>34
replace hrs_c =4 if hrs1==40
replace hrs_c =5 if hrs1<50& hrs1>40
replace hrs_c =6 if hrs1<60& hrs1>49
replace hrs_c =7 if hrs1<161& hrs1>59
la var hrs_c "working hrs cat."

gen hrs_lo=(hrs_c<4&hrs_c>0)
replace hrs_lo=. if hrs_c==.
gen hrs_hi=(hrs_c>4&hrs_c<10)
replace hrs_hi=. if hrs_c==.
tab hrs_c ,gen(hrs_c_d)
gen incXhrs_c=inc*hrs_c

gen hrs_hiXeb=hrs_hi*eb
gen hrs_loXeb=hrs_lo*eb

forval i=1/9{
replace gss_reg_d`i'=0 if ds_id=="eb96"|ds_id=="eb01"
}

codebook ctry, tab(100)
gen latin=0
replace latin=1 if ctry==1|ctry==10|ctry==5|ctry==12|ctry==11
gen scan=0
replace scan=1 if ctry==7|ctry==15|ctry==14|ctry==16
gen gb=0
replace gb=1 if ctry==8|ctry==9
gen cont=0
replace cont=((latin==0 & scan==0 & gb==0)& ds_id!="gss")

gen hrs_cXeb=hrs_c*eb
gen hrs1Xeb=hrs1*eb
la var hrs_cXeb "working hrs cat $*$ Europe"
la var eb "Europe"

xtile hrs_d= hrs1 , nq(4)
gen hrs1_2=hrs1^2

*// probably do not need this 
/* gen latinXhrs_c=latin*hrs_c */
/* gen scanXhrs_c =scan*hrs_c */
/* gen gbXhrs_c   =gb*hrs_c */

*//--  
replace year=1996 if ds_id=="eb96"
replace year=2001 if ds_id=="eb01"

gen ctry_reg=ctry
replace ctry_reg=gss_region*1000 if ctry==.
tab ctry_reg, mi

gen hrs_dXeb=hrs_d*eb


la def hrs_c_lbl 1"<17" 2"17-34" 3"35-39" 4"40" 5"41-49" 6"50-59" 7"60-160"
la val hrs_c hrs_c_lbl


la var hrs1 "working hours"
la var hrs_lo "less than 40 hours"
la def hrs_lo_lbl 0 "40 hours or more " 1"less than 40 hours"
la val hrs_lo hrs_lo_lbl
la var hrs_hi "more than 40 hrs"
la def hrs_hi_lbl 0 "40 hours or less" 1"more than 40 hours"
la val hrs_hi hrs_hi_lbl

la var happy "happy"
la var hrs1Xeb "working hours $*$ Europe"
la var inc "household income"
la var male "male"
la var hrs_c "working hours category"

la var hrs_dXeb "working hours quartiles $*$ Europe"
la var hrs_d "working hours quartiles "
la var hrs_loXeb "less than 40 hours $*$ Europe"
la var hrs_hiXeb "more than 40 hrs $*$ Europe"

la var ds_id "datasets"
la var ctry "European countries"
la var gss_region "American regions"
la def eb_lbl 1"Europeans" 0"Americans"
la val eb eb_lbl

la var gss_health "health"
la var eb01_health "health"

la var gss_fam_tim "family time"
la var eb96_fam_tim "family time"
la var eb01_fam_tim "family time"

la var gss_fnd "friends"
la var eb96_fnd "friends"
la var eb01_fnd "friends"

la var gss_ext_hrs "extra hours"
la var eb96_ext_hrs "extra hours"
la var eb01_ext_hrs "extra hours"


la var eb01_occ "occupation"
la var isco1 "occupation"
la var eb96_occ1 "occupation"


save dat/appended.dta, replace

*//----------------

use  dat/appended.dta, clear

/* finally we are getting down to descriptive stats--most of the work was to clean up data and prepare */
/* it for the analysis */

*---------------------------------------------------------
*//des stats
*cd out/
*//descriptive histogram
bys eb hrs_c : egen happy_m=mean(happy)
la var happy_m "happy"
twoway (bar happy_m hrs_c if ds_id=="gss", sort fcolor(black)) (bar happy_m hrs_c if eb==1, fcolor(white) lcolor(black) lwidth(vvvthin) barwidth(.5)), legend(on order(1 "Americans" 0 "Europeans")) xlabel(1 2 3 4 5 6 7 , valuelabel) scheme(s2mono)
graph export out/comparison.eps, as(eps)  replace
sh(epstopdf out/comparison.eps)                        

histogram hrs1, bin(10) percent xtitle(working hours) xlabel(#10) scheme(s2mono) by(eb)
graph export out/hist_hrs.eps, as(eps)  replace
sh(epstopdf out/hist_hrs.eps)                        


histogram happy, percent xtitle(happy) xlabel(#10) scheme(s2mono) by(eb) dis
graph export out/hist_happy.eps, as(eps)  replace
sh(epstopdf out/hist_happy.eps)                        


*//summary stats
net  from http://fmwww.bc.edu/RePEc/bocode/f
net install fre


loc pre "\begin{table}\begin{center}\begin{scriptsize} \caption{`v'} \begin{tabular}{lllrrrr}\hline &&Freq.&Per.&Val. Per.&Cum. Per\\ \hline"
loc post "\hline \end{tabular}\end{scriptsize} \end{center} \end{table}"

 sh(rm out/fre.tex)
foreach v of varlist  hrs_c ds_id  ctry gss_region  {
  fre `v' using  out/fre.tex, format(0)   novalue tex append  bodyonly pre(`pre') post(`post')
}

sh(rm out/fre_gss.tex)
foreach v of varlist  gss_fam_tim gss_ext_hrs gss_fnd gss_health isco1 {
  fre `v'    using  out/fre_gss.tex, format(0)   novalue tex append  bodyonly pre(`pre') post(`post')
}

sh(rm out/fre_eb01.tex)
foreach v of varlist  eb01_fam_tim eb01_ext_hrs eb01_fnd eb01_health eb01_occ {
  fre `v'   using  out/fre_eb01.tex, format(0)   novalue tex append  bodyonly pre(`pre') post(`post')
}

sh(rm out/fre_eb96.tex)
foreach v of varlist  eb96_fam_tim eb96_ext_hrs eb96_fnd  eb96_occ1 {
  fre `v'   using  out/fre_eb96.tex, format(0)   novalue tex append  bodyonly pre(`pre') post(`post')
}


*//regressions
loc f2 i.ctry_reg

loc x1 inc  mar age age2  male
loc x2 inc  mar age age2    

xi: ologit happy  hrs1Xeb  hrs1 eb  `x1'  `f2'  i.year , or  robust
*//outreg2 using out/reg1.xls, onecol bdec(2) st(coef) excel replace ct(A1) eform lab
est sto a1

xi: ologit happy  hrs_cXeb  hrs_c eb  `x1'  `f2'  i.year , or  robust
est sto a2

xi: ologit happy  hrs_dXeb  hrs_d eb  `x1'  `f2'  i.year , or  robust
est sto a3

xi: ologit happy hrs_loXeb   hrs_lo   eb  `x1'  `f2'  i.year , or  robust
est sto a4

xi: ologit happy hrs_hiXeb   hrs_hi   eb  `x1'  `f2'  i.year , or  robust
est sto a5

estout a*  using out/reg1.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "A1" "A2" "A3" "A4" "A5") collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )


xi3: ologit happy  i.eb*hrs1  hrs1 eb  `x1'  `f2'  i.year , or  robust
postgr3 hrs1, by(eb) outcome(3)  ytitle(predicted probability of being very happy) xtitle(working hours category) title(A1) legend(order( 1 "Americans" 2 "Europeans" )) lpattern( dash default) lcolor(black black) scheme(s2mono)  saving(g1, replace)

xi3: ologit happy  i.eb*hrs_c  hrs_c eb  `x1'  `f2'  i.year , or  robust
postgr3 hrs_c, by(eb) outcome(3)  ytitle(predicted probability of being very happy) xtitle(working hours category) title(A2) legend(order( 1 "Americans" 2 "Europeans" )) lpattern( dash default) lcolor(black black) scheme(s2mono) xlabel(1(1)7,  valuelabel) saving(g2, replace)

gr combine g1.gph g2.gph, r(1)
graph export out/pp1.eps, as(eps)  replace
sh(epstopdf out/pp1.eps)
*sh(convert out/pp1.pdf -rotate "360" out/pp1.pdf)



xi3: ologit happy  i.eb*hrs_lo  hrs_lo eb  `x1'  `f2'  i.year , or  robust
postgr3 hrs_lo, by(eb) outcome(3)  ytitle(predicted probability of being very happy) xtitle(working hours category) title(A4) legend(order( 1 "Americans" 2 "Europeans" )) lpattern( dash default) lcolor(black black) scheme(s2mono) xlabel(0 1,  valuelabel) saving(g3, replace)

xi3: ologit happy  i.eb*hrs_hi  hrs_hi eb  `x1'  `f2'  i.year , or  robust
postgr3 hrs_hi, by(eb) outcome(3)  ytitle(predicted probability of being very happy) xtitle(working hours category) title(A5) legend(order( 1 "Americans" 2 "Europeans" )) lpattern( dash default) lcolor(black black) scheme(s2mono) xlabel(0 1,   valuelabel) saving(g4, replace)

gr combine  g3.gph g4.gph, r(1)
graph export out/pp2.eps, as(eps)  replace
sh(epstopdf out/pp2.eps)

*//ideally with confifdence intervals but the thibg below is for logit, not ologit and messesss up....
/* preserve */
/* drop if ctry_reg==1000 */
/* xi: adjust  `x1' `f2' i.year , se gen(xb se) */
/* gen pr = invlogit(xb) */
/* gen lb = invlogit(xb - invnormal(.975)*se) */
/* gen ub = invlogit(xb + invnormal(.975)*se) */
/* sort eb hrs_c  */
/* twoway rarea lb ub hrs_c if eb == 0, fcolor(gs12) lcolor(black)|| rarea lb ub hrs_c if eb == 1 , fcolor(gs12) lcolor(black)|| line pr hrs_c if eb == 0 , lcolor(black) lpattern(dash)    || line pr hrs_c if eb == 1,  lcolor(black) lwidth(thick) lpattern(solid) legend(order(3 "Americans" 4 " Europeans" )) scheme(s2mono) title(`c') */
/* graph export out/g_prob.ps ,as(ps)  logo(off) tmargin(0) lmargin(0) replace */
/* drop xb se pr lb ub */
/* restore */


*//below regressions for the appendix  

*//general
xi: ologit happy  hrs_c   `x1' `f2' i.year    if  (ds_id=="gss" ) , or  robust
est sto b1

xi: ologit happy  hrs_c   `x1' `f2' i.year    if  (ds_id=="eb96" ) , or  robust
est sto b2

xi: ologit happy  hrs_c   `x1' `f2' i.year    if  (ds_id=="eb01" ) , or  robust
est sto b3


*//extra hours
xi: ologit happy  hrs_c   `x1' `f2' i.year  gss_ext_hrs  if  (ds_id=="gss" ) , or  robust
est sto c1

xi: ologit happy  hrs_c   `x1' `f2' i.year eb96_ext_hrs   if  (ds_id=="eb96" ) , or  robust
est sto c2

xi: ologit happy  hrs_c   `x1' `f2' i.year eb01_ext_hrs   if  (ds_id=="eb01" ) , or  robust
est sto c3

*//family time
xi: ologit happy  hrs_c   `x1' `f2' i.year  gss_fam_tim     if  (ds_id=="gss" ) , or  robust
est sto d1

xi: ologit happy  hrs_c   `x1' `f2' i.year  eb96_fam_tim     if  (ds_id=="eb96" ) , or  robust
est sto d2

xi: ologit happy  hrs_c   `x1' `f2' i.year  eb01_fam_tim     if  (ds_id=="eb01" ) , or  robust
est sto d3

*//health
xi: ologit happy  hrs_c   `x1' `f2' i.year gss_health     if  (ds_id=="gss" ) , or  robust
est sto e1

xi: ologit happy  hrs_c   `x1' `f2' i.year eb01_health     if  (ds_id=="eb01" ) , or  robust
est sto e2

*//friends
xi: ologit happy  hrs_c   `x1' `f2' i.year gss_fnd     if  (ds_id=="gss" ) , or  robust
est sto f1

xi: ologit happy  hrs_c   `x1' `f2' i.year eb96_fnd     if  (ds_id=="eb96" ) , or  robust
est sto f2

xi: ologit happy  hrs_c   `x1' `f2' i.year eb01_fnd     if  (ds_id=="eb01" ) , or  robust
est sto f3

*//occupation

xi: ologit happy  hrs_c   `x1' `f2' i.year i.isco1     if  (ds_id=="gss" ) , or  robust
est sto g1

xi: ologit happy  hrs_c   `x1' `f2' i.year i.eb96_occ1     if  (ds_id=="eb96" ) , or  robust
est sto g2

xi: ologit happy  hrs_c   `x1' `f2' i.year i.eb01_occ     if  (ds_id=="eb01" ) , or  robust
est sto g3


estout c*  using out/reg_c.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS" "EB96" "EB01" ) collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )


estout d*  using out/reg_d.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS" "EB96" "EB01" ) collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )


estout e*  using out/reg_e.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS" "EB96" ) collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )

estout f*  using out/reg_f.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS" "EB96" "EB01" ) collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )


estout g1 g2 g3  using out/reg_g.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS" "EB96" "EB01" ) collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop( _cons*  )

*//some of the estyout export underscores and latex complain, so let's replace them
sh(sed  -i 's|_||g' ~/desk/papers/old/2009/ditella/REPLICATION/out/reg*)



*//##################### revise and resubmit double check ##############################

xi: ologit happy  hrs1Xeb  hrs1 eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
*//outreg2 using out/reg1.xls, onecol bdec(2) st(coef) excel replace ct(A1) eform lab
est sto a1

xi: ologit happy  hrs_cXeb  hrs_c eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto a2

xi: ologit happy  hrs_dXeb  hrs_d eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto a3

xi: ologit happy hrs_loXeb   hrs_lo   eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto a4

xi: ologit happy hrs_hiXeb   hrs_hi   eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto a5

estout a*  using out/reg1.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "A1" "A2" "A3" "A4" "A5") collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )

  
preserve
replace happy=happy_alt if ds_id=="eb96"

xi: ologit happy  hrs1Xeb  hrs1 eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
*//outreg2 using out/reg1.xls, onecol bdec(2) st(coef) excel replace ct(A1) eform lab
est sto b1

xi: ologit happy  hrs_cXeb  hrs_c eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto b2

xi: ologit happy  hrs_dXeb  hrs_d eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto b3

xi: ologit happy hrs_loXeb   hrs_lo   eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto b4

xi: ologit happy hrs_hiXeb   hrs_hi   eb  `x1'  `f2'  i.year if ds_id!="eb01" , or  robust
est sto b5

estout b*  using out/reg2.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable})posthead(\hline) prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "B1" "B2" "B3" "B4" "B5") collabels(, none) eform cells(b(star fmt(%9.3f))) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons Constant) starl(* .1 ** .05 *** .01) label drop(_I* _cons*  )

restore



























********************************************old**********************************************
 



  
xi: ologit happy hrs_c  inc incXhrs_c  mar age age2  reg_d* if (ds_id=="gss"& year==2000),or  robust
est sto gss

xi: ologit happy hrs_c inc  mar age age2  latin scan gb if ds_id=="gss",or  robust
est sto gss

xi: ologit happy  hrs_cXgss  inc hrs_c gss   mar age age2  reg_d* scan gb latin  if (ds_id=="gss"& year==2000)|  (ds_id=="eb01" ),or  robust
est sto gss

xi: ologit happy hrs_c inc  mar age age2  latin scan gb if ds_id=="eb01",or  robust
est sto gss


*//here pooled
xi: ologit happy  hrs_cXeb  inc hrs_c eb   mar age age2  reg_d* scan gb latin  if (ds_id=="gss"& year==2000)|  (ds_id=="eb01" ),or  robust
est sto gss00

xi: ologit happy  hrs_cXeb  inc hrs_c eb   mar age age2  reg_d* scan gb latin  if (ds_id=="gss"& year==2002)|  (ds_id=="eb01" ),or  robust
est sto gss02

xi: ologit happy  hrs_cXeb  inc hrs_c eb   mar age age2  reg_d* scan gb latin  if (ds_id=="gss"& year==1996)|  (ds_id=="eb96" ),or  robust
est sto gss96


estout gss96 gss00 gss02  using out/table.tex , replace style(tex)prehead(\begin{tabular}{lcccccc} \hline\hline {Variable}                  )posthead(\hline)  prefoot(\hline) postfoot(\hline\hline \end{tabular}) mlabel( "GSS96-EB96" "GSS00-EB01" "GSS02-EB01" "(4)"                                            "(5)" "(6)") collabels(,                                                                   none) eform cells(b(star fmt(%9.3f)) se(par)) stats(N, labels( "N" ) fmt(%9.0f %9.0f))varlabels(_cons  Constant) starl(* .1 ** .05 *** .01) label
sh(scp ~/ditella/out/table.tex aok@aok123.info:~/desk/papers/ditella/out)

save  dat/all.dta, replace

loc d="~/desk/papers/ditella/"
preserve
keep if (ds_id=="gss"& year==2000)|  (ds_id=="eb01" )
xi3: ologit happy  i.eb*hrs_c  inc hrs_c eb mar age age2 scan gb latin  , robust
postgr3 hrs_c, by(eb) outcome(3)  ytitle(Predicted Probability of Being Very Happy) xtitle(Working Hours Category) title() legend(order(2 "Europeans" 1 "Americans" )) lpattern( dash default) lcolor(black black) xlabel(1(1)7)
graph export out/vh1.eps, replace
restore

preserve
keep if (ds_id=="gss"& year==2000)|  (ds_id=="eb01" )
xi3: ologit happy  i.gss*hrs1  inc hrs1 gss   mar age age2 scan gb latin  , robust
postgr3 hrs1, by(gss) outcome(3)
restore

preserve
keep if  (ds_id=="eb01" )
gen europe=.
replace europe=1 if scan==1
replace europe=2 if gb==1
replace europe=3 if latin==1
xi3: ologit happy  i.europe*hrs1  inc  i.europe   mar age age2 , robust
postgr3 hrs1, by(europe) outcome(3)

restore

preserve
keep if  (ds_id=="eb01" )
gen europe=.

xi3: ologit happy  i.ctry*hrs1  inc  i.ctry   mar age age2 , robust
postgr3 hrs1, by(ctry) outcome(3)

restore

preserve
keep if (ds_id=="gss"& year==2000)|  (ds_id=="eb01" )
replace ctry=25 if gss==1
xi3: ologit happy  i.gss*hrs1  inc hrs1 gss   mar age age2 i.ctry , robust
postgr3 hrs1, by(gss) outcome(3)
restore




***************Scrap****************

*-------------------------------------------------------------------
use  dat/gss3.dta, clear
graph bar (mean) satjob, over(hrs_c) title(us_sat_job)
graph export out/us_sat_job.png, replace
graph bar (mean) happy, over(hrs_c) title(us_happy)
graph export out/us_happy.png, replace

ologit satjob hrs1 age age2 income mar, or robust

/* keep unemp prestg80 year happy satfin  satjob1 satjob7 satfam7 hrs2 hrs1 workhr hrsmoney age age2 hh_inc r_inc mar timefrnd mustwork moredays wktopsat satjob jobmeans hrsrelax hrsmoney hrs_c */

/* gen hrs_lo=(hrs_c<4&hrs_c>0) */
/* replace hrs_lo=. if hrs_c==. */
/* gen hrs_hi=(hrs_c>4&hrs_c<10) */
/* replace hrs_hi=. if hrs_c==. */

gen hh_incXhrs_c=hh_inc*hrs_c
  
/* foreach n in 1994 1996 1998 2000 2002 2004 2006{ */
/* ologit happy hrs_c  unemp mar age age2  if year==`n',  robust */
/* est sto a1 */
/* *outreg2 using out/gss.xls, excel ct(yr`n') append */
/* ologit happy hh_inc unemp mar age age2  if year==`n',  robust */
/* est sto a2 */
/* *outreg2 using out/gss.xls, excel ct(yr`n') append */
/* ologit happy hrs_c hh_inc hh_incXhrs_c unemp mar age age2  if year==`n',  robust */
/* est sto a3 */
/* *outreg2 using out/gss.xls, excel ct(yr`n') append */
/* } */

  
xi: ologit happy hrs_c  hh_inc unemp mar age age2   i.region if year==2002 ,or  robust
est sto gss02

xi: ologit happy hrs_c  hh_inc unemp mar age age2  i.region if year==2006 ,or  robust
est sto gss00

xi: ologit happy hrs_c  hh_inc unemp mar age age2  i.region if year==1996 , or  robust
est sto gss96


codebook isco88
tostring isco88, gen(isco88_1)
tab isco88_1
replace isco88_1="0110" if isco88_1=="110"
gen isco88_s=substr(isco88_1, -4,2)
drop isco88_1 isco88
destring isco88_s, gen(isco88)
tab isco88
drop if isco88==75|isco==84
graph hbar (mean) happy if year==2002, over(isco88, sort(happy))
graph export out/gss02_ls_occ.ps, replace 

*//happy hrs_c even yrs
*//timefrnd 89 98 06
*//rinc 06
*//
  
*-------------------------------------------------------------------
use dat/soc_exc2.dta, clear

xi: ologit life_sts hrs_c  inc mar un age age2 latin scan gb , or robust
est sto eb01

graph hbar (mean) life_sts, over(V162, sort(life_sts))
graph export out/eu01_ls_occ.ps, replace 

*___
*scrap

/* graph bar (mean) life_sat, over(hrs_c) title(eu_life_sat) */
/* graph export out/eu_life_sat.png, replace */
/* graph bar (mean) job_sat, over(hrs_c) title(eu_job_sat) */
/* graph export out/eu_job_sat.png, replace */
/* graph bar (mean) soc_sat, over(hrs_c) title(eu_soc_sat) */
/* graph export out/eu_soc_sat.png, replace */
/* ologit job_sat hrs friends inc mar un age age2, or */

*-------------------------------------------------------------------
use dat/emp_gender2.dta, clear

ologit life_sts hrs1_c  inc mar unemp age age2 latin scan gb, or robust
est sto eb96

estout gss96 gss00 gss02 eb96 eb01  using out/gss3.xls, replace style(tab) eform cells(b(star fmt(%9.2f))) collabels(yr) stats(N, labels( "\$n\$" ) fmt(%9.0f)) varlabels(_cons Constant) label legend 

tab v80, nola
graph hbar (mean) life_sts, over(v80, sort(life_sts))
graph export out/eu96_ls_occ.ps, replace 


capture mkdir ~/Desktop/graphs
graph bar (mean) happy if year==2002, over(hrs1) title(us_happy)
graph export ~/Desktop/graphs/us_happy.ps, replace

graph bar (mean) satjob1 if year==2002, over(hrs1) title(us_sat_job1)
graph export ~/Desktop/graphs/us_sat_job1.ps, replace

